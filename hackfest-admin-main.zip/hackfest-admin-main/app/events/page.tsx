'use client'

import { useState, useRef, useEffect } from 'react'
import { motion } from 'framer-motion'
import { format } from 'date-fns'
import HeatmapVisualization from "@/components/heatmap-visualization"
import IssueSelector from "@/components/issue-selector"
// import { ThemeProvider } from "@/components/theme-provider"
import SentimentAnalysisDashboard from '@/components/post-grid'
import DatePicker from '@/components/date-picker'
import {
  BarChart3,
  Bell,
  ChevronRight,
  LineChart,
  PieChart,
  Plus,
  Send,
  Upload,
  X,
  Download,
  Activity,
  Flame,
  Thermometer
} from 'lucide-react'
import { PieChartComponent, LineChartComponent } from '@/components/chart'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Button } from '@/components/ui/button'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import html2canvas from "html2canvas"
import jsPDF from "jspdf"
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from '@/components/ui/sheet'



export default function Dashboard() {
const [events, setEvents] = useState<any>([]);
  const [selectedEvent, setSelectedEvent] = useState<any>(null)
  const [eventData, setEventData] = useState<any>()
//   const eventData = sentimentData.find((data) => data.id === selectedEvent?.id) || {
//     id: 0,
//     data: [],
//     keywords: [],
//     issues: [],
//     positives: [],
//   }
  type Block = {
    topLeft: { x: number; y: number };
    bottomRight: { x: number; y: number };
  };  
  const [notificationText, setNotificationText] = useState('')
  const [img, setImg] = useState<any>(null)
  const [open, setOpen] = useState(false);
  const [open2, setOpen2] = useState(false);


  const [newEvent, setNewEvent] = useState<{
    name: string;
    date: string;
    category: string;
    passkey:string;
    location: string;
    description: string;
    blocks: Block[];
  }>({
    name: '',
    date: '',
    category: '',
    passkey:'',
    location: '',
    description: '',
    blocks: [],
  });
  const [mapImage, setMapImage] = useState<any>(null)
  const canvasRef = useRef(null)
  const [isDrawing, setIsDrawing] = useState(false)
  const [blocks, setBlocks] = useState<any>([])
  const [startPos, setStartPos] = useState<any>(null)
  const [currentBlock, setCurrentBlock] = useState<any>(null)

  const handleImageUpload = (e: any) => {
    const file = e.target.files?.[0];
    setImg(file);
    if (file) {
      const reader = new FileReader()
      reader.onload = (event: any) => {
        setMapImage(event.target?.result)
      }
      reader.readAsDataURL(file)
    }
  }

  const startDrawing = (e: any) => {
    if (!canvasRef.current) return
    const canvas: any = canvasRef.current
    const rect = canvas.getBoundingClientRect()
    const x = e.clientX - rect.left
    const y = e.clientY - rect.top
    setStartPos({ x, y })
    setIsDrawing(true)
  }

  const draw = (e: any) => {
    if (!isDrawing || !startPos || !canvasRef.current) return
    const canvas: any = canvasRef.current
    const rect = canvas.getBoundingClientRect()
    const x = e.clientX - rect.left
    const y = e.clientY - rect.top 

    const width = x - startPos.x
    const height = y - startPos.y

    setCurrentBlock({
      x: startPos.x,
      y: startPos.y,
      width,
      height,
    })
  }

  const stopDrawing = () => {
    if (isDrawing && currentBlock) {
        const canvas: any = canvasRef.current;

        const topLeft = { 
            x: currentBlock.x, 
            y: currentBlock.y + currentBlock.height
          };
          const bottomRight = { 
            x: currentBlock.x + currentBlock.width, 
            y: canvas.height - currentBlock.y 
          };
      
        console.log(topLeft);
        console.log(bottomRight);
      setBlocks([...blocks, currentBlock])
      setNewEvent(prev => ({
        ...prev,
        blocks: [
          ...prev.blocks,
          { topLeft, bottomRight }
        ]
      }));      
  
    }
    setIsDrawing(false)
    setCurrentBlock(null)
  }

  useEffect(() => {
    if (!canvasRef.current || !mapImage) return

    const canvas: any = canvasRef.current
    const ctx = canvas.getContext('2d')
    if (!ctx) return

    const img = new Image()
    img.crossOrigin = 'anonymous'
    img.src = mapImage

    img.onload = () => {
      // Clear canvas
      ctx.clearRect(0, 0, canvas.width, canvas.height)

      // Draw image
      ctx.drawImage(img, 0, 0, canvas.width, canvas.height)

      // Draw existing blocks
      ctx.strokeStyle = '#10b981'
      ctx.lineWidth = 2
      blocks.forEach((block: any) => {
        ctx.strokeRect(block.x, block.y, block.width, block.height)
      })

      // Draw current block if drawing
      if (currentBlock) {
        ctx.strokeStyle = '#3b82f6'
        ctx.strokeRect(currentBlock.x, currentBlock.y, currentBlock.width, currentBlock.height)
      }
    }
  }, [mapImage, blocks, currentBlock])

  useEffect(() => {
    type SentimentLabel = 'Positive' | 'Negative' | 'Neutral';

    type SentimentCount = {
      positive: number;
      negative: number;
      neutral: number;
    };
    
    const sentimentCountByDate: Record<string, SentimentCount> = {};
    
    selectedEvent?.posts?.forEach((post:any) => {
      const dateObj = new Date(post.timestamp);
      const label: SentimentLabel = post.sentiment.label;
    
      const options = { month: 'short', day: 'numeric' } as const;
      const formattedDate = dateObj.toLocaleDateString('en-US', options); // e.g., 'Apr 3'
    
      if (!sentimentCountByDate[formattedDate]) {
        sentimentCountByDate[formattedDate] = { positive: 0, negative: 0, neutral: 0 };
      }
    
      if (label === 'Positive') sentimentCountByDate[formattedDate].positive += 1;
      else if (label === 'Negative') sentimentCountByDate[formattedDate].negative += 1;
      else sentimentCountByDate[formattedDate].neutral += 1;
    });
    
    const result = Object.entries(sentimentCountByDate).map(([date, counts]) => ({
      date,
      ...counts,
    }));
    
    console.log(result);
    setEventData(result);
    

  },[selectedEvent])

  useEffect(() => {
    const fetchEvents = async () => {
      try {
        const res = await fetch('http://localhost:5000/api/events'); // Adjust URL if using proxy or relative API route
        const data = await res.json();;
        console.log(data.events)
        setEvents(data.events);
        setSelectedEvent(data.events[0]);
        
      } catch (error) {
        console.error('Error fetching events:', error);
      }
    };

    fetchEvents();
  }, []);


  const handleSendNotification = async () => {
    try {
        const response = await fetch('http://localhost:5000/api/events/alert', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ eventId: selectedEvent._id, alert: notificationText.trim() }),
        });
    
        const result = await response.json();
    
        if (!response.ok) {
          throw new Error(result.error || 'Failed to add alert');
        }
    
        console.log('✅ Alert added:', result);
        setNotificationText('');
        // Optionally, show success toast here
      } catch (error) {
        console.error('❌ Error adding alert:', error);
        // Optionally, show error toast here
      } finally {
        setOpen(false);
      }
  }

  const handleCreateEvent = async () => {
    // if (!newEvent.name || !newEvent.date || !newEvent.category) {
    //   alert('Please fill in all required fields')
    //   return
    // }
    const formData = new FormData();
    formData.append('image', img);

    try {
        const resMap = await fetch('http://localhost:5000/api/upload', {
            method: 'POST',
            body: formData
          });
        
        const dataMap = await resMap.json();
        
        const res = await fetch('http://localhost:5000/api/events', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({...newEvent, map_url: dataMap.url})
        })
  
        if (!res.ok) throw new Error('Failed to create event')
        const data = await res.json()
        console.log('Created event:', data)
      } catch (err: any) {
        console.log("err");
      } finally {
        setOpen2(false);
      }
  
    alert(`Event creatked: ${newEvent.name}`)
    setNewEvent({
      name: '',
      date: format(new Date(), 'yyyy-MM-dd'),
      category: '',
      passkey:'',
      location: '',
      description: '',
      blocks: [] 
    })
    setMapImage(null)
    setBlocks([])
  }
  const [selectedIssue, setSelectedIssue] = useState<string | null>(null)

  // Extract all unique issue types from the data
  const issueTypes = Array.from(new Set(selectedEvent?.blocks.flatMap((item:any) => Object.keys(item.problems)))) as string[]

  const handleExport = async () => {
    document.getElementById("chart-container")?.classList.add("export-mode")
    const doc = new jsPDF("p", "mm", "a4")
    const elements = document.querySelectorAll(".chart-container")

    for (let i = 0; i < elements.length; i++) {
      const element = elements[i] as HTMLElement
      const canvas = await html2canvas(element, { scale: 2 })
      const imgData = canvas.toDataURL("image/png")

      const imgProps = doc.getImageProperties(imgData)
      const pdfWidth = doc.internal.pageSize.getWidth()
      const pdfHeight = (imgProps.height * pdfWidth) / imgProps.width

      if (i !== 0) doc.addPage()
      doc.addImage(imgData, "PNG", 0, 0, pdfWidth, pdfHeight)
    }

    doc.save("dashboard-charts.pdf")
    document.getElementById("chart-container")?.classList.remove("export-mode")
  }



  return (
    <div className="flex min-h-screen flex-col bg-[#121212] text-gray-100">
        <style jsx global>{`
      .chart-container {
        page-break-inside: avoid;
        margin-bottom: 20px;
      }
      
      @media print {
        body {
          background-color: white !important;
        }
        .chart-container {
          background-color: white !important;
          color: black !important;
        }
      }
    `}</style>
      <div className="flex flex-1">
        <aside className="w-64 border-r border-gray-800 bg-[#1a1a1a]">
          <div className="flex h-14 items-center border-b border-gray-800 px-4">
            <h2 className="text-lg font-semibold text-white">Events Dashboard</h2>
          </div>
          <ScrollArea className="h-[calc(100vh-3.5rem)]">
            <div className="px-2 py-2">
              <h3 className="mb-2 px-4 text-sm font-medium text-gray-400">Events</h3>
              <div className="space-y-1 mb-4">
                {events.map((event:any, id:number) => (
                  <motion.div
                    key={id}
                    onClick={() => setSelectedEvent(event)}
                    className={`w-full rounded-md px-4 py-2 text-left text-sm transition-all hover:bg-gray-800 hover:text-white ${
                      selectedEvent?.id === event.id ? 'bg-gray-800 text-white' : 'text-gray-300'
                    }`}
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                  >
                    <div className="font-medium">{event.name}</div>
                    <div className="text-xs text-gray-500">{event.date.split("T")[0]}</div>
                  </motion.div>
                ))}
              </div>
              

              <div className="px-4 mt-6">
                <Dialog open={open2} onOpenChange={setOpen2}>
                  <DialogTrigger asChild>
                    <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
                      <Button
                        className="w-full bg-gray-800 hover:bg-gray-700 text-white border border-gray-700"
                        size="sm"
                      >
                        <Plus className="mr-2 h-4 w-4" />
                        Create New Event
                      </Button>
                    </motion.div>
                  </DialogTrigger>
                  <DialogContent className="sm:max-w-[600px] bg-[#1a1a1a] border border-gray-800 text-gray-100 max-h-[80vh] overflow-y-auto">
                    <DialogHeader>
                      <DialogTitle className="text-white">Create New Event</DialogTitle>
                      <DialogDescription className="text-gray-400">
                        Fill in the details to create a new event. Click save when you're done.
                      </DialogDescription>
                    </DialogHeader>
                    <div className="grid gap-4 py-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div className="grid gap-2">
                          <Label htmlFor="name" className="text-gray-300">
                            Event Name
                          </Label>
                          <Input
                            id="name"
                            value={newEvent.name}
                            onChange={(e) => setNewEvent({ ...newEvent, name: e.target.value })}
                            placeholder="Product Launch 2025"
                            className="bg-[#222] border-gray-700 text-gray-100"
                          />
                        </div>
                        <div className="grid gap-2">
                          <Label htmlFor="date" className="text-gray-300">
                            Date
                          </Label>
                          <div className="flex flex-col gap-4">
                            <DatePicker
                              value={newEvent.date ? new Date(newEvent.date) : undefined}
                              onChange={(date) =>
                                setNewEvent((prev) => ({
                                  ...prev,
                                  date: date?.toISOString() || '',
                                }))
                              }
                            />
                          </div>
                        </div>
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div className="grid gap-2">
                          <Label htmlFor="category" className="text-gray-300">
                            Category
                          </Label>
                          <Input
                            id="category"
                            value={newEvent.category}
                            onChange={(e) => setNewEvent({ ...newEvent, category: e.target.value })}
                            placeholder="Marketing"
                            className="bg-[#222] border-gray-700 text-gray-100"
                          />
                        </div>
                        <div className="grid gap-2">
                          <Label htmlFor="location" className="text-gray-300">
                            Location
                          </Label>
                          <Input
                            id="location"
                            value={newEvent.location}
                            onChange={(e) => setNewEvent({ ...newEvent, location: e.target.value })}
                            placeholder="Convention Center"
                            className="bg-[#222] border-gray-700 text-gray-100"
                          />
                        </div>
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div className="grid gap-2">
                          <Label htmlFor="category" className="text-gray-300">
                            PassKey
                          </Label>
                          <Input
                            id="passkey"
                            value={newEvent.passkey}
                            onChange={(e) => setNewEvent({ ...newEvent, passkey: e.target.value })}
                            type="password"
                            placeholder="Secret PassKey"
                            className="bg-[#222] border-gray-700 text-gray-100"
                          />
                        </div>
                      </div>
                      <div className="grid gap-2">
                        <Label htmlFor="description" className="text-gray-300">
                          Description
                        </Label>
                        <Textarea
                          id="description"
                          value={newEvent.description}
                          onChange={(e) =>
                            setNewEvent({ ...newEvent, description: e.target.value })
                          }
                          placeholder="Event description..."
                          rows={3}
                          className="bg-[#222] border-gray-700 text-gray-100"
                        />
                      </div>
                      <div className="grid gap-2">
                        <Label className="text-gray-300">Event Map</Label>
                        <div className="flex flex-col gap-4">
                          <div className="flex items-center gap-2">
                            <Label htmlFor="map-upload" className="cursor-pointer">
                              <div className="flex h-10 items-center justify-center rounded-md border border-gray-700 bg-[#222] px-4 py-2 text-sm font-medium text-gray-300 transition-colors hover:bg-gray-800 hover:text-white">
                                <Upload className="mr-2 h-4 w-4" />
                                Upload Map Image
                              </div>
                              <Input
                                id="map-upload"
                                type="file"
                                accept="image/*"
                                className="hidden"
                                onChange={handleImageUpload}
                              />
                            </Label>
                            {mapImage && (
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => setMapImage(null)}
                                className="border-gray-700 text-gray-300 hover:bg-gray-800 hover:text-white"
                              >
                                <X className="mr-2 h-4 w-4" />
                                Remove
                              </Button>
                            )}
                          </div>

                          {mapImage && (
                            <div className="relative border border-gray-700 rounded-md p-2 bg-[#222]">
                              <div className="text-xs text-gray-400 mb-2">
                                Click and drag to draw blocks on the map
                              </div>
                              <canvas
                                ref={canvasRef}
                                width={500}
                                height={300}
                                className="w-full h-auto border border-gray-700 rounded cursor-crosshair"
                                onMouseDown={startDrawing}
                                onMouseMove={draw}
                                onMouseUp={stopDrawing}
                                onMouseLeave={stopDrawing}
                              />
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                    <DialogFooter>
                      <Button
                        onClick={handleCreateEvent}
                        className="bg-emerald-600 hover:bg-emerald-700 text-white"
                      >
                        Create Event
                      </Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>
              </div>
            </div>
          </ScrollArea>
        </aside>
        <main className="flex-1 overflow-auto bg-[#121212]">
          <div className="flex h-14 items-center justify-between border-b border-gray-800 bg-[#1a1a1a] px-4">
            <div className="flex items-center gap-4">
              <h1 className="text-lg font-semibold text-white">{selectedEvent?.name}</h1>
              <div className="text-sm text-gray-400">{selectedEvent?.date.split("T")[0]}</div>
              <div className="rounded-full bg-emerald-600/20 px-2 py-1 text-xs font-medium text-emerald-400">
                {selectedEvent?.category}
              </div>
            </div>
            <div className="flex items-center gap-4">
            <Button
      onClick={handleExport}
      className="bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white font-semibold px-6 py-3 rounded-xl shadow-lg transition-all duration-300 flex items-center gap-2"
    >
      <Download className="w-5 h-5" />
      Download Report
    </Button>
              <Sheet open={open} onOpenChange={setOpen}>
                <SheetTrigger asChild>
                  <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                    <Button
                      variant="outline"
                      size="sm"
                      className="border-gray-700 text-gray-300 hover:bg-gray-800 hover:text-white"
                    >
                      <Bell className="mr-2 h-4 w-4" />
                      Send Notification
                    </Button>
                  </motion.div>
                </SheetTrigger>
                <SheetContent className="bg-[#1a1a1a] border-l border-gray-800 text-gray-100">
                  <SheetHeader>
                    <SheetTitle className="text-white">Send Event Notification</SheetTitle>
                    <SheetDescription className="text-gray-400">
                      Send an important notification about {selectedEvent?.name} to all
                      participants.
                    </SheetDescription>
                  </SheetHeader>
                  <div className="grid gap-4 py-4">
                    <div className="grid gap-2">
                      <Label htmlFor="notification" className="text-gray-300">
                        Notification Message
                      </Label>
                      <Textarea
                        id="notification"
                        value={notificationText}
                        onChange={(e) => setNotificationText(e.target.value)}
                        placeholder="Type your notification message here..."
                        rows={5}
                        className="bg-[#222] border-gray-700 text-gray-100"
                      />
                    </div>
                    <div className="flex items-center gap-2">
                      <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                        <Button
                          onClick={handleSendNotification}
                          className="bg-emerald-600 hover:bg-emerald-700 text-white"
                        >
                          <Send className="mr-2 h-4 w-4" />
                          Send Notification
                        </Button>
                      </motion.div>
                    </div>
                  </div>
                </SheetContent>
              </Sheet>
            </div>
          </div>
          <div className="container mx-auto p-4">
            <Tabs defaultValue="overview" className="space-y-4">
              <TabsList className="bg-[#222] border border-gray-800">
                <TabsTrigger
                  value="overview"
                  className="data-[state=active]:bg-gray-800 data-[state=active]:text-white text-gray-400"
                >
                  <LineChart className="mr-2 h-4 w-4" />
                  Sentiment Analysis
                </TabsTrigger>
                <TabsTrigger
                  value="keywords"
                  className="data-[state=active]:bg-gray-800 data-[state=active]:text-white text-gray-400"
                >
                  <PieChart className="mr-2 h-4 w-4" />
                  Keyword Analysis
                </TabsTrigger>
                <TabsTrigger
                  value="insights"
                  className="data-[state=active]:bg-gray-800 data-[state=active]:text-white text-gray-400"
                >
                  <BarChart3 className="mr-2 h-4 w-4" />
                  Key Insights
                </TabsTrigger>
                <TabsTrigger
                  value="heatmap"
                  className="data-[state=active]:bg-gray-800 data-[state=active]:text-white text-gray-400"
                >
                  <Flame className="mr-2 h-4 w-4" />
                  Heatmap
                </TabsTrigger>
              </TabsList>
              <TabsContent value="overview" className="space-y-4">
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5 }}
                  className='chart-container'
                  id='chart-container'
                >
                  <Card className="bg-[#1a1a1a] border-gray-800 shadow-lg shadow-emerald-900/5">
                    <CardHeader>
                      <CardTitle className="text-white"><span className="inline-block w-3 h-3 rounded-full bg-emerald-500 mr-2"></span>
                      Sentiment Analysis Over Time</CardTitle>
                      <CardDescription className="text-gray-400">
                        Tracking positive, negative, and neutral sentiment for {selectedEvent?.name}
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="h-[300px]">
                      <LineChartComponent data={eventData || []} />
                    </CardContent>
                  </Card>
                </motion.div>

                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3, delay: 0.1 }}
                  >
                    <Card className="bg-[#1a1a1a] border-gray-800 shadow-lg shadow-emerald-900/5 overflow-scroll">
                      <CardHeader>
                      <CardTitle className="text-white"><span className="inline-block w-3 h-3 rounded-full bg-emerald-500 mr-2"></span>
                      Sentiment Distribution For The Event</CardTitle>
                      </CardHeader>
                      <CardContent className="h-[250px]">
                        <PieChartComponent
                          data={[
                            { name: 'Positive', value: selectedEvent?.analysis?.overall_sentiment?.distribution?.positive || 0 },
                            { name: 'Negative', value: selectedEvent?.analysis?.overall_sentiment?.distribution?.negative || 0 },
                            { name: 'Neutral', value: selectedEvent?.analysis?.overall_sentiment?.distribution?.neutral || 0 },
                          ]}
                          keyword={"Overall"}
                        />
                      </CardContent>
                    </Card>
                  </motion.div>
                
              </TabsContent>
              <TabsContent value="keywords" className="grid gap-4 md:grid-cols-2 chart-container" id="chart-container">
                {selectedEvent?.analysis?.keyword_sentiment?.keywords?.map((keyw:any, index:any) => (
                  <motion.div
                    key={keyw}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3, delay: index * 0.1 }}
                  >
                    <Card className="bg-[#1a1a1a] border-gray-800 shadow-lg shadow-emerald-900/5 overflow-hidden">
                      <CardHeader>
                        <CardTitle className="text-white">
                          Sentiment distribution for all keyword
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="h-[250px]">
                        <PieChartComponent
                          data={[
                            { name: 'Positive', value: selectedEvent?.analysis?.keyword_sentiment?.distribution?.[keyw]?.positive || 0 },
                            { name: 'Negative', value: selectedEvent?.analysis?.keyword_sentiment?.distribution?.[keyw]?.negative || 0 },
                            { name: 'Neutral', value: selectedEvent?.analysis?.keyword_sentiment?.distribution?.[keyw]?.neutral || 0 },
                          ]}
                          keyword={keyw}
                        />
                      </CardContent>
                    </Card>
                  </motion.div>
                ))}
              </TabsContent>
              <TabsContent value="insights" className="grid gap-4 md:grid-cols-2">
                <motion.div
                  initial={{ opacity: 0, x: -50 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.5 }}
                  className='chart-container'
                  id="chart-container"
                >
                  <Card className="bg-[#1a1a1a] border-gray-800 shadow-lg shadow-rose-900/5">
                    <CardHeader>
                      <CardTitle className="flex items-center text-rose-400">
                        <ChevronRight className="mr-2 h-5 w-5" />
                        Top 5 Issues
                      </CardTitle>
                      <CardDescription className="text-gray-400">
                        Key concerns identified from feedback
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <ul className="space-y-2">
                        {selectedEvent?.analysis?.issues_and_positives?.negative.map((issue:string, index:any) => (
                          <motion.li
                            key={index}
                            initial={{ opacity: 0, x: -20 }}
                            animate={{ opacity: 1, x: 0 }}
                            transition={{ duration: 0.3, delay: index * 0.1 }}
                            className="flex items-start gap-2 rounded-md border border-gray-800 bg-[#222] p-3"
                            whileHover={{
                              scale: 1.02,
                              boxShadow: '0 0 8px rgba(239, 68, 68, 0.3)',
                            }}
                          >
                            <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-rose-900/30 text-xs font-medium text-rose-400">
                              {index + 1}
                            </span>
                            <span className="text-gray-300">{issue}</span>
                          </motion.li>
                        ))}
                      </ul>
                    </CardContent>
                  </Card>
                </motion.div>
                <motion.div
                  initial={{ opacity: 0, x: 50 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.5 }}
                >
                  <Card className="bg-[#1a1a1a] border-gray-800 shadow-lg shadow-emerald-900/5">
                    <CardHeader>
                      <CardTitle className="flex items-center text-emerald-400">
                        <ChevronRight className="mr-2 h-5 w-5" />
                        Top 5 Positives
                      </CardTitle>
                      <CardDescription className="text-gray-400">
                        Key strengths identified from feedback
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <ul className="space-y-2">
                        {selectedEvent?.analysis?.issues_and_positives?.positive.map((positive:string, index:number) => (
                          <motion.li
                            key={index}
                            initial={{ opacity: 0, x: 20 }}
                            animate={{ opacity: 1, x: 0 }}
                            transition={{ duration: 0.3, delay: index * 0.1 }}
                            className="flex items-start gap-2 rounded-md border border-gray-800 bg-[#222] p-3"
                            whileHover={{
                              scale: 1.02,
                              boxShadow: '0 0 8px rgba(16, 185, 129, 0.3)',
                            }}
                          >
                            <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-emerald-900/30 text-xs font-medium text-emerald-400">
                              {index + 1}
                            </span>
                            <span className="text-gray-300">{positive}</span>
                          </motion.li>
                        ))}
                      </ul>
                    </CardContent>
                  </Card>
                </motion.div>
                <div
                  className='col-span-2 w-full'
                >
                    <SentimentAnalysisDashboard data={selectedEvent?.posts}/>
                </div>
                
              </TabsContent>
              <TabsContent value="heatmap" className="space-y-4">
              <main className="container mx-auto py-8 min-h-screen bg-background chart-container" id="chart-container">
        <Card className="mb-8 border-border bg-card">
          <CardHeader>
            <CardTitle>Issue Heatmap Visualization</CardTitle>
            <CardDescription>
              Select an issue type to visualize its distribution and intensity across the image
            </CardDescription>
          </CardHeader>
          <CardContent>
            <IssueSelector issues={issueTypes} selectedIssue={selectedIssue} onSelectIssue={setSelectedIssue} />
          </CardContent>
        </Card>

        <Card className="border-border bg-card">
          <CardContent className="p-6">
            <HeatmapVisualization data={selectedEvent?.blocks as any} selectedIssue={selectedIssue} map_url={selectedEvent?.map_url} />
          </CardContent>
        </Card>
      </main>
                
              </TabsContent>
            </Tabs>
          </div>
        </main>
      </div>
    </div>
  )
}

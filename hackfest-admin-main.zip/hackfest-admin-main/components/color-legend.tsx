interface ColorLegendProps {
    issue: string
    maxCount: number
  }
  
  export default function ColorLegend({ issue, maxCount }: ColorLegendProps) {
    // Generate color based on issue type
    const getBaseColor = () => {
      switch (issue) {
        case "Overcrowding":
          return "rgb(255, 0, 0)" // Red
        case "Poor Lighting":
          return "rgb(0, 0, 255)" // Blue
        case "Ventilation Issues":
          return "rgb(0, 128, 0)" // Green
        default:
          return "rgb(128, 0, 128)" // Purple
      }
    }
  
    // Generate gradient steps
    const generateGradientSteps = () => {
      const baseColor = getBaseColor()
      const steps = 5
      return Array.from({ length: steps }, (_, i) => {
        const alpha = 0.2 + (i / (steps - 1)) * 0.8
        return baseColor.replace("rgb", "rgba").replace(")", `, ${alpha})`)
      })
    }
  
    const gradientSteps = generateGradientSteps()
  
    return (
      <div className="mt-4">
        <h4 className="text-sm font-medium mb-2">{issue} Intensity</h4>
        <div className="flex items-center">
          <div className="flex h-6 w-full rounded overflow-hidden">
            {gradientSteps.map((color, index) => (
              <div key={index} className="flex-1 h-full" style={{ backgroundColor: color }} />
            ))}
          </div>
          <div className="flex justify-between w-full text-xs text-muted-foreground mt-1">
            <span>Low</span>
            <span>High ({maxCount})</span>
          </div>
        </div>
      </div>
    )
  }
  
  
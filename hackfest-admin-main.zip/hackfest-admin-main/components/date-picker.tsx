'use client'

import * as React from 'react'
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover'
import { Button } from '@/components/ui/button'
import { Calendar } from '@/components/ui/calendar'
import { format } from 'date-fns'
import { CalendarIcon } from 'lucide-react'

export default function DatePicker({
  value,
  onChange,
}: {
  value?: Date
  onChange: (date: Date) => void
}) {
  const [selectedDate, setSelectedDate] = React.useState<Date | undefined>(value)

  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button variant="outline" className="w-[250px] justify-start text-left">
          <CalendarIcon className="w-4 h-4 mr-2" />
          {selectedDate ? format(selectedDate, 'PPP') : 'Pick a date'}
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-auto p-0">
        <Calendar
          mode="single"
          selected={selectedDate}
          onSelect={(date) => {
            setSelectedDate(date)
            onChange(date as Date)
          }}
          initialFocus
        />
      </PopoverContent>
    </Popover>
  )
}

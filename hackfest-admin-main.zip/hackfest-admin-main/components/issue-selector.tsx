"use client"

import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface IssueSelectorProps {
  issues: string[]
  selectedIssue: string | null
  onSelectIssue: (issue: string) => void
}

export default function IssueSelector({ issues, selectedIssue, onSelectIssue }: IssueSelectorProps) {
  return (
    <div className="space-y-4">
      <h3 className="text-lg font-medium">Select Issue Type</h3>
      <Select value={selectedIssue || ""} onValueChange={onSelectIssue}>
        <SelectTrigger className="w-full sm:w-[280px]">
          <SelectValue placeholder="Select an issue to visualize" />
        </SelectTrigger>
        <SelectContent>
          {issues.map((issue) => (
            <SelectItem key={issue} value={issue}>
              {issue}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  )
}


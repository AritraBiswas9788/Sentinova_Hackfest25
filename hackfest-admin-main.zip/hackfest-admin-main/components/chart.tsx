
import {
  LineChart as RechartsLineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart as RechartsPieChart,
  Pie,
  Cell,
  Legend,
  Label
} from 'recharts'

// Chart components
export const LineChartComponent = ({ data }: { data: any }) => {
  if (!data || data.length === 0) {
    return <div className="flex h-full items-center justify-center">No data available</div>
  }

  return (
    <ResponsiveContainer width="100%" height="100%">
      <RechartsLineChart
        data={data}
        margin={{
          top: 20,
          right: 30,
          left: 20,
          bottom: 50,
        }}
      >
        <CartesianGrid strokeDasharray="3 3" stroke="#333" />
        <XAxis dataKey="date" angle={-45} textAnchor="end" tick={{ fill: '#888' }} stroke="#444" />
        <YAxis tickFormatter={(value) => `${value}%`} tick={{ fill: '#888' }} stroke="#444" />
        <Tooltip
          contentStyle={{
            backgroundColor: '#222',
            border: '1px solid #333',
            borderRadius: '8px',
            boxShadow: '0 4px 12px rgba(0, 0, 0, 0.5)',
          }}
          itemStyle={{ color: '#ccc' }}
          labelStyle={{ color: '#fff', fontWeight: 'bold' }}
        />
        <Line
          type="monotone"
          dataKey="positive"
          stroke="#10b981"
          strokeWidth={2}
          dot={{ r: 4, fill: '#10b981', strokeWidth: 0 }}
          activeDot={{ r: 6, fill: '#10b981', stroke: '#fff', strokeWidth: 2 }}
          animationDuration={1500}
          className="drop-shadow-glow-green"
        />
        <Line
          type="monotone"
          dataKey="negative"
          stroke="#ef4444"
          strokeWidth={2}
          dot={{ r: 4, fill: '#ef4444', strokeWidth: 0 }}
          activeDot={{ r: 6, fill: '#ef4444', stroke: '#fff', strokeWidth: 2 }}
          animationDuration={1500}
          className="drop-shadow-glow-red"
        />
        <Line
          type="monotone"
          dataKey="neutral"
          stroke="#9ca3af"
          strokeWidth={2}
          dot={{ r: 4, fill: '#9ca3af', strokeWidth: 0 }}
          activeDot={{ r: 6, fill: '#9ca3af', stroke: '#fff', strokeWidth: 2 }}
          animationDuration={1500}
          className="drop-shadow-glow-gray"
        />
      </RechartsLineChart>
    </ResponsiveContainer>
  )
}

export const PieChartComponent = ({ data, keyword }: { data: any, keyword:any }) => {
  if (!data || data.length === 0) {
    return <div className="flex h-full items-center justify-center">No data available</div>
  }
  const COLORS = ['#10b981', '#ef4444', '#9ca3af']

  return (
    <ResponsiveContainer width="100%" height="100%">
      <RechartsPieChart>
        <Pie
          data={data}
          cx="50%"
          cy="50%"
          innerRadius={80}
          outerRadius={90}
          paddingAngle={5}
          dataKey="value"
          animationDuration={1500}
          animationBegin={200}
          className="drop-shadow-glow"
        >
          {data.map((entry: any, index: any) => (
            <Cell
              key={`cell-${index}`}
              fill={COLORS[index % COLORS.length]}
              className={`drop-shadow-glow-${index === 0 ? 'green' : index === 1 ? 'red' : 'gray'}`}
            />
          ))}
        </Pie>
        <text
            x="50%"
            y="50%"
            textAnchor="middle"
            dominantBaseline="middle"
            fontSize={18}
            fontWeight="bold"
            fill="#fff" 
            >
                {keyword}
            </text>
        <Tooltip
          contentStyle={{
            backgroundColor: '#222',
            border: '1px solid #333',
            borderRadius: '8px',
            boxShadow: '0 4px 12px rgba(0, 0, 0, 0.5)',
          }}
          itemStyle={{ color: '#ccc' }}
          formatter={(value) => [`${value}%`, '']}
        />
        <Legend
          formatter={(value) => <span style={{ color: '#ccc' }}>{value}</span>}
          iconType="circle"
        />
      </RechartsPieChart>
    </ResponsiveContainer>
  )
}

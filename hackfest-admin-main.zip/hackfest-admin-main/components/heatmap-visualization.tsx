"use client"

import { useEffect, useRef, useState } from "react"

interface Box {
  topLeft: { x: number; y: number }
  bottomRight: { x: number; y: number }
  _id: string
  problems: Record<string, number>
}

interface HeatmapVisualizationProps {
  data: Box[]
  selectedIssue: string | null,
  map_url: string
}

export default function HeatmapVisualization({ data, selectedIssue, map_url }: HeatmapVisualizationProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [canvasSize, setCanvasSize] = useState({ width: 800, height: 600 })
  const [maxCount, setMaxCount] = useState(0)

  // Find the boundaries of all boxes to determine canvas dimensions
  useEffect(() => {
    if (!data || data.length === 0) return

    let minX = Number.POSITIVE_INFINITY
    let minY = Number.POSITIVE_INFINITY
    let maxX = Number.NEGATIVE_INFINITY
    let maxY = Number.NEGATIVE_INFINITY

    data.forEach((box) => {
      minX = Math.min(minX, box.topLeft.x)
      minY = Math.min(minY, box.bottomRight.y) // Note: y is inverted
      maxX = Math.max(maxX, box.bottomRight.x)
      maxY = Math.max(maxY, box.topLeft.y) // Note: y is inverted
    })

    // Add some padding
    const padding = 50
    setCanvasSize({
      width: maxX - minX + padding * 2,
      height: maxY - minY + padding * 2,
    })
  }, [data])

  // Find the maximum count for the selected issue
  useEffect(() => {
    if (!selectedIssue || !data) {
      setMaxCount(0)
      return
    }

    let max = 0
    data.forEach((box) => {
      const count = box.problems[selectedIssue] || 0
      max = Math.max(max, count)
    })
    setMaxCount(max)
  }, [data, selectedIssue])

useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || !selectedIssue) return;
  
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
  
    const image = new Image();
    image.src = map_url;
  
    image.onload = () => {
      // Clear canvas before drawing
      ctx.clearRect(0, 0, canvas.width, canvas.height);
  
      // Draw background image
      ctx.drawImage(image, 0, 0, canvas.width, canvas.height);
  
      // Draw each box (AFTER image is drawn)
      data.forEach((box) => {
        const count = box.problems[selectedIssue] || 0;
        if (count > 0) {
          const intensity = maxCount > 0 ? count / maxCount : 0;
          const alpha = 0.3 + intensity * 0.7;
  
          let color;
          switch (selectedIssue) {
            case "Overcrowding":
              color = `rgba(255, 50, 50, ${alpha})`;
              break;
            case "Poor Lighting":
              color = `rgba(50, 120, 255, ${alpha})`;
              break;
            case "Ventilation Issues":
              color = `rgba(50, 200, 100, ${alpha})`;
              break;
            default:
              color = `rgba(200, 100, 200, ${alpha})`;
          }
  
          const x = box.topLeft.x;
          const y = box.bottomRight.y;
          const width = box.bottomRight.x - box.topLeft.x;
          const height = box.topLeft.y - box.bottomRight.y;
  
          ctx.fillStyle = color;
          ctx.fillRect(x, y, width, height);
  
          // Add border
          ctx.strokeStyle = "rgba(255, 255, 255, 0.5)";
          ctx.lineWidth = 1;
          ctx.strokeRect(x, y, width, height);
  
          // Add count text
          ctx.fillStyle = "white";
          ctx.font = "12px Arial";
          ctx.textAlign = "center";
          ctx.textBaseline = "middle";
          ctx.fillText(count.toString(), x + width / 2, y + height / 2);
        }
      });
  
      // Optional: Draw legend if needed
      drawLegend(ctx, selectedIssue);
    };
  }, [data, selectedIssue, maxCount, canvasSize]);
  

  // Function to draw the legend
  const drawLegend = (ctx: CanvasRenderingContext2D, issue: string) => {
    const legendX = 20
    const legendY = 20
    const legendWidth = 200
    const legendHeight = 30

    // Draw legend title
    ctx.fillStyle = "white" // White text for dark theme
    ctx.font = "bold 14px Arial"
    ctx.textAlign = "left"
    ctx.fillText(`${issue} Intensity`, legendX, legendY - 5)

    // Draw gradient bar
    const gradient = ctx.createLinearGradient(legendX, 0, legendX + legendWidth, 0)

    let color1, color2
    switch (issue) {
      case "Overcrowding":
        color1 = "rgba(255, 50, 50, 0.3)"
        color2 = "rgba(255, 50, 50, 1.0)"
        break
      case "Poor Lighting":
        color1 = "rgba(50, 120, 255, 0.3)"
        color2 = "rgba(50, 120, 255, 1.0)"
        break
      case "Ventilation Issues":
        color1 = "rgba(50, 200, 100, 0.3)"
        color2 = "rgba(50, 200, 100, 1.0)"
        break
      default:
        color1 = "rgba(200, 100, 200, 0.3)"
        color2 = "rgba(200, 100, 200, 1.0)"
    }

    gradient.addColorStop(0, color1)
    gradient.addColorStop(1, color2)

    ctx.fillStyle = gradient
    ctx.fillRect(legendX, legendY, legendWidth, legendHeight)

    // Draw border around gradient
    ctx.strokeStyle = "rgba(255, 255, 255, 0.5)" // White border for dark theme
    ctx.lineWidth = 1
    ctx.strokeRect(legendX, legendY, legendWidth, legendHeight)

    // Draw min and max labels
    ctx.fillStyle = "white" // White text for dark theme
    ctx.font = "12px Arial"
    ctx.textAlign = "left"
    ctx.fillText("Low", legendX, legendY + legendHeight + 15)

    ctx.textAlign = "right"
    ctx.fillText("High", legendX + legendWidth, legendY + legendHeight + 15)
  }

  return (
    <div className="flex flex-col items-center">
      {!selectedIssue ? (
        <div className="flex items-center justify-center h-[400px] w-full">
          <p className="text-muted-foreground text-lg">
            Please select an issue type from the dropdown to view the heatmap
          </p>
        </div>
      ) : (
        <>
          <div className="mb-4">
            <h3 className="text-lg font-medium">Heatmap for {selectedIssue}</h3>
            <p className="text-sm text-muted-foreground">Darker colors indicate higher counts of the selected issue</p>
          </div>
          <div className="border border-border rounded-lg p-4 bg-card overflow-auto">
            <canvas ref={canvasRef} width={canvasSize.width} height={canvasSize.height} className="max-w-full" />
          </div>
        </>
      )}
    </div>
  )
}


"use client"

import type React from "react"

import { useEffect, useState, useRef } from "react"
import { motion, useAnimationControls } from "framer-motion"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Facebook, Linkedin, MessageSquare, ThumbsUp } from "lucide-react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

// Sample data - in a real app, this would come from your API
const samplePosts = [
  {
    id: 1,
    platform: "reddit",
    username: "user123",
    text: "This product has completely changed my workflow. Highly recommend!",
    sentiment:{label: "positive"},
    likes: 42,
    comments: 7,
    timestamp: "2h ago",
  },
  {
    id: 2,
    platform: "instagram",
    username: "photoexplorer",
    text: "Not impressed with the latest update. Several features are now harder to use.",
    sentiment: {label:"negative"},
    likes: 18,
    comments: 12,
    timestamp: "4h ago",
  },
  {
    id: 3,
    platform: "linkedin",
    username: "professional_dev",
    text: "Interesting approach to solving this common industry problem.",
    sentiment:{label: "neutral"},
    likes: 56,
    comments: 3,
    timestamp: "1d ago",
  }
]

// Platform-specific styling
const platformStyles = {
  Reddit: {
    glow: "shadow-[0_0_20px_rgba(255,45,0,0.8)]", // Enhanced red glow
    icon: () => (
      <svg viewBox="0 0 24 24" className="w-4 h-4 fill-current text-[#FF2D00]">
        <path d="M12 0A12 12 0 0 0 0 12a12 12 0 0 0 12 12 12 12 0 0 0 12-12A12 12 0 0 0 12 0zm5.01 4.744c.688 0 1.25.561 1.25 1.249a1.25 1.25 0 0 1-2.498.056l-2.597-.547-.8 3.747c1.824.07 3.48.632 4.674 1.488.308-.309.73-.491 1.207-.491.968 0 1.754.786 1.754 1.754 0 .716-.435 1.333-1.01 1.614a3.111 3.111 0 0 1 .042.52c0 2.694-3.13 4.87-7.004 4.87-3.874 0-7.004-2.176-7.004-4.87 0-.183.015-.366.043-.534A1.748 1.748 0 0 1 4.028 12c0-.968.786-1.754 1.754-1.754.463 0 .898.196 1.207.49 1.207-.883 2.878-1.43 4.744-1.487l.885-4.182a.342.342 0 0 1 .14-.197.35.35 0 0 1 .238-.042l2.906.617a1.214 1.214 0 0 1 1.108-.701zM9.25 12C8.561 12 8 12.562 8 13.25c0 .687.561 1.248 1.25 1.248.687 0 1.248-.561 1.248-1.249 0-.688-.561-1.249-1.249-1.249zm5.5 0c-.687 0-1.248.561-1.248 1.25 0 .687.561 1.248 1.249 1.248.688 0 1.249-.561 1.249-1.249 0-.687-.562-1.249-1.25-1.249zm-5.466 3.99a.327.327 0 0 0-.231.094.33.33 0 0 0 0 .463c.842.842 2.484.913 2.961.913.477 0 2.105-.056 2.961-.913a.361.361 0 0 0 .029-.463.33.33 0 0 0-.464 0c-.547.533-1.684.73-2.512.73-.828 0-1.979-.196-2.512-.73a.326.326 0 0 0-.232-.095z" />
      </svg>
    ),
    bgClass: "bg-gradient-to-br from-red-950/90 to-black/90", // Added red gradient
    textClass: "text-red-400",
  },
  Instagram: {
    glow: "shadow-[0_0_15px_rgba(193,53,132,0.7)]",
    icon: () => (
      <svg viewBox="0 0 24 24" className="w-4 h-4 fill-current text-[#C13584]">
        <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zM12 0C8.741 0 8.333.014 7.053.072 2.695.272.273 2.69.073 7.052.014 8.333 0 8.741 0 12c0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98C8.333 23.986 8.741 24 12 24c3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98C15.668.014 15.259 0 12 0zm0 5.838a6.162 6.162 0 1 0 0 12.324 6.162 6.162 0 0 0 0-12.324zM12 16a4 4 0 1 1 0-8 4 4 0 0 1 0 8zm6.406-11.845a1.44 1.44 0 1 0 0 2.881 1.44 1.44 0 0 0 0-2.881z" />
      </svg>
    ),
    bgClass: "bg-gradient-to-tr from-purple-900/90 to-pink-700/90",
    textClass: "text-pink-400",
  },
  Linkedin: {
    glow: "shadow-[0_0_15px_rgba(0,119,181,0.7)]",
    icon: () => <Linkedin className="w-4 h-4 text-[#0077B5]" />,
    bgClass: "bg-blue-950/90",
    textClass: "text-blue-400",
  },
  X: {
    glow: "shadow-[0_0_15px_rgba(255,255,255,0.5)]",
    icon: () => (
      <svg viewBox="0 0 24 24" className="w-4 h-4 fill-current text-white">
        <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z" />
      </svg>
    ),
    bgClass: "bg-zinc-900",
    textClass: "text-gray-300",
  },
  Facebook: {
    glow: "shadow-[0_0_15px_rgba(66,103,178,0.7)]",
    icon: () => <Facebook className="w-4 h-4 text-[#4267B2]" />,
    bgClass: "bg-blue-900/90",
    textClass: "text-blue-300",
  },
}

// Sentiment badge styling
const sentimentStyles = {
  positive: "bg-green-500/20 text-green-500 border-green-500/50",
  negative: "bg-red-500/20 text-red-500 border-red-500/50",
  neutral: "bg-yellow-500/20 text-yellow-500 border-yellow-500/50",
}

interface PostCardProps {
  post: {
    id: number
    platform: string
    username: string
    text: string
    sentiment: {
        label:string
    }
    likes: number
    comments: number
    timestamp: string
  }
  index: number
}

const PostCard = ({ post, index }: PostCardProps) => {
    
  const platform = post.platform as keyof typeof platformStyles
    
  const style = platformStyles[platform]
  console.log(style);

if (!style) {
  return null // or fallback UI
}

const { glow, icon: PlatformIcon, bgClass, textClass } = style

//   const sentimentClass = sentimentStyles[post.sentiment as keyof typeof sentimentStyles]
console.log(textClass);
  return (
    <div className="relative p-4">
      {" "}
      {/* Added padding for glow visibility */}
      {/* Smear/trail effect */}
      <div
        className="absolute inset-0 blur-xl opacity-30 -z-10 rounded-xl"
        style={{
          background:
            platform === "Reddit"
              ? "linear-gradient(90deg, rgba(255,45,0,0.15), transparent)"
              : platform === "Instagram"
                ? "linear-gradient(90deg, rgba(193,53,132,0.15), transparent)"
                : platform === "Linkedin"
                  ? "linear-gradient(90deg, rgba(0,119,181,0.15), transparent)"
                  : platform === "X"
                    ? "linear-gradient(90deg, rgba(255,255,255,0.15), transparent)"
                    : "linear-gradient(90deg, rgba(66,103,178,0.15), transparent)",
        }}
      />
      <Card className={`overflow-hidden border-0 ${glow} ${bgClass} w-[280px]`}>
        <CardContent className="p-4">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <Avatar className="w-8 h-8 border border-white/10">
                <AvatarImage src={`/placeholder.svg?height=32&width=32`} />
                <AvatarFallback className="text-xs">{post.username.substring(0, 2).toUpperCase()}</AvatarFallback>
              </Avatar>
              <div>
                <p className={`text-sm font-medium ${textClass}`}>@{post.username}</p>
                <div className="flex items-center gap-1 text-xs text-gray-400">
                  <PlatformIcon />
                  <span>{post.timestamp}</span>
                </div>
              </div>
            </div>
            <Badge variant="outline" className={`text-xs`}>
              {post.sentiment.label as any}
            </Badge>
          </div>
          <p className="text-sm text-gray-200 mb-3">{post.text.split(' ').slice(0, 30).join(' ')}{post.text.split(' ').length > 30 ? '...' : ''}</p>
          <div className="flex items-center gap-4 text-xs text-gray-400">
            <div className="flex items-center gap-1">
              <ThumbsUp className="w-3.5 h-3.5" />
              <span>{post.likes}</span>
            </div>
            <div className="flex items-center gap-1">
              <MessageSquare className="w-3.5 h-3.5" />
              <span>{post.comments}</span>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

// Create a continuous scrolling row of posts with a truly cyclic animation
const InfiniteScrollRow = ({
  posts,
  direction = "left",
  speed = 30,
  verticalOffset = 0,
}: {
  posts: typeof samplePosts
  direction?: "left" | "right"
  speed?: number
  verticalOffset?: number
}) => {
  const containerRef = useRef<HTMLDivElement>(null)
  const [containerWidth, setContainerWidth] = useState(0)
  const controls = useAnimationControls()

  // Calculate the width of a single post card (including padding/margin)
  const postWidth = 340 // Width of post + padding

  // Calculate how many posts we need to fill the screen width
  const postsNeeded = 30

  // Create an array with enough posts to fill the screen
  const displayPosts = [...Array(postsNeeded)].map((_, i) => posts[i % posts.length])
  console.log(displayPosts);

  // Set up the animation
  useEffect(() => {
    if (!containerRef.current) return

    // Measure the container width
    const updateWidth = () => {
      if (containerRef.current) {
        setContainerWidth(containerRef.current.offsetWidth)
      }
    }

    updateWidth()
    window.addEventListener("resize", updateWidth)

    // Start the animation
    const startAnimation = async () => {
      // Calculate the total width of all posts
      const totalWidth = displayPosts.length * postWidth

      // Calculate the time needed to scroll based on speed
      const duration = totalWidth / speed

      // Set the initial position
      await controls.set({
        x: direction === "left" ? 0 : -totalWidth + containerWidth,
      })

      // Start the infinite loop animation
      controls.start({
        x: direction === "left" ? -totalWidth + containerWidth : 0,
        transition: {
          duration: duration,
          ease: "linear",
          repeat: Number.POSITIVE_INFINITY,
          repeatType: "loop",
        },
      })
    }

    startAnimation()

    return () => {
      window.removeEventListener("resize", updateWidth)
    }
  }, [containerWidth, direction, displayPosts.length, speed, controls])

  return (
    <div
      ref={containerRef}
    //   className="relative overflow-hidden w-full"
    //   style={{ transform: `translateY(${verticalOffset}px)` }}
    >
      <motion.div className="flex" animate={controls}>
        {displayPosts.map((post, index) => (
          <PostCard key={`${index}`} post={post} index={index} />
        ))}
      </motion.div>
    </div>
  )
}

// Create an irregular brushstroke-like shape for the viewport
// const BrushstrokeViewport = ({ children }: { children: React.ReactNode }) => {
//   // SVG path for a brushstroke-like shape - wider to show more content
//   const brushstrokePath = `
//     M 10,20 
//     C 50,0 100,10 150,5 
//     C 200,0 250,10 300,5 
//     C 350,0 400,10 450,5 
//     C 500,0 550,10 600,5 
//     C 650,0 700,10 750,5 
//     C 800,0 850,10 900,5 
//     C 950,0 1000,10 1050,5 
//     C 1100,0 1150,10 1200,5 
//     C 1250,0 1300,10 1350,5 
//     C 1400,0 1450,10 1500,5 
//     C 1500,100 1500,200 1500,300 
//     C 1450,310 1400,290 1350,300 
//     C 1300,310 1250,290 1200,300 
//     C 1150,310 1100,290 1050,300 
//     C 1000,310 950,290 900,300 
//     C 850,310 800,290 750,300 
//     C 700,310 650,290 600,300 
//     C 550,310 500,290 450,300 
//     C 400,310 350,290 300,300 
//     C 250,310 200,290 150,300 
//     C 100,310 50,290 10,300 
//     C 10,250 10,150 10,20
//   `

//   return (
//     <div className="relative w-full h-[500px] overflow-hidden">
//       <svg
//         width="100%"
//         height="100%"
//         viewBox="0 0 1500 300"
//         preserveAspectRatio="none"
//         className="absolute inset-0 z-10 pointer-events-none"
//       >
//         <defs>
//           <clipPath id="brushstroke">
//             <path d={brushstrokePath} />
//           </clipPath>
//         </defs>
//       </svg>

//       <div
//         className="absolute inset-0 overflow-hidden"
//         style={{
//           clipPath: "url(#brushstroke)",
//           background: "radial-gradient(ellipse at center, rgba(30,30,30,0.7) 0%, rgba(10,10,10,0.9) 70%)",
//         }}
//       >
//         {children}
//       </div>
//     </div>
//   )
// }

export default function SentimentAnalysisDashboard({ data } : {data:any;}) {
  // Shuffle and prepare posts for each row
  const shuffleArray = (arr: typeof samplePosts) => {
    return [...arr].sort(() => Math.random() - 0.5)
  }

  // Create 3 rows of posts with different speeds and directions
  const rows = [
    {
      posts: shuffleArray(data),
      direction: "left" as const,
      speed: 30,
      verticalOffset: 30,
    },
    {
      posts: shuffleArray(data),
      direction: "right" as const,
      speed: 30,
      verticalOffset: 150,
    },
    {
      posts: shuffleArray(data),
      direction: "left" as const,
      speed: 30,
      verticalOffset: 270,
    },
  ]
  console.log(rows);

  return (
    <div className="max-h-[50vh] bg-gray-950 p-6 overflow-hidden">
      <div className="max-w-7xl mx-auto">
        <h1 className="text-2xl font-bold text-white mb-6">Social Media Sentiment Analysis</h1>
        <div className="relative">
          {/* Background glow effects */}
          <div className="absolute inset-0 bg-gradient-to-r from-purple-900/10 via-blue-900/10 to-red-900/10 blur-3xl -z-1" />

          {/* Brushstroke viewport with scrolling rows */}
            {rows.map((row, index) => (
              <InfiniteScrollRow
                key={index}
                posts={row.posts}
                direction={row.direction}
                speed={row.speed}
                verticalOffset={row.verticalOffset}
              />
            ))}
        </div>
      </div>
    </div>
  )
}

